select c.city, sum(c.grade) sum_of_grade from customer c group by c.city
select * from customer c join salesman s on c.salesman_id = s.salesman_id where s.commission > 0.12 order by c. customer_id
